using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Primitives;

namespace CC.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public StringValues amount { get; set; }
        public double euro { get; set; }

        public string FromCurrency { get; set; }
        public string ToCurrency { get; set; }

        public double amountInGbp { get; set; }

        public double convertedAmount { get; set; }

        public double originalAmount { get; set; }

        public bool isSubmitted { get; set; }

        public double conversionRate = 1.17;
        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        private readonly Dictionary<string, double> _conversionRates = new Dictionary<string, double>
        {
            { "GBP", 1.0 },  // Base rate for GBP
            { "EUR", 1.17 },
            { "USD", 1.25 },
            { "JPY", 150.0 }
        };




        public void OnGet()
        {

        }
        public void OnPost()
        {
            amount = Request.Form["amount"];
            FromCurrency = Request.Form["fromCurrency"];
            ToCurrency = Request.Form["toCurrency"];

            if (double.TryParse(amount, out double originalAmount) && originalAmount >= 0)
            {
                double amountInGbp;
                this.originalAmount = originalAmount;

                //uses dictionary to get rate associated with the currency,this rate is to 
                //get the amount in gbp so it can then be converted with less inefficient code

                if (_conversionRates.TryGetValue(FromCurrency, out Double fromRate) &&
                    _conversionRates.TryGetValue(ToCurrency, out Double toRate))
                {
                    amountInGbp = originalAmount / fromRate;
                    convertedAmount = Math.Round(amountInGbp * toRate, 2, MidpointRounding.AwayFromZero);
                    isSubmitted = true;
                }

                else
                {
                    ModelState.AddModelError("", "Invalid entry.");
                    isSubmitted = false;
                    return;
                }
  

            }
            else
            {
                ModelState.AddModelError("amount", "Invalid amount entered. Please enter a valid number.");
                isSubmitted = false;
            }

        }
    }
}
